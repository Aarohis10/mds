import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.stream.IntStream;
public class DataSet{
    private static double temp;
    private String[][] data=null;
    private double entropy=0;
    private int columns = 0;
    private ArrayList<Feature> features=null;
    public DataSet(String[][] data) {
        this.data = data;
        this.columns = data[0].length;
        new Feature(data, data[0].length - 1).getFeatureValues().stream().forEach(featureValue -> entropy += minusPlog2((double) featureValue.getOccurences() / (data.length - 1)));
    }

    public String[][] getData(){return data;}
    public double getEntropy(){ return entropy;}
    public ArrayList<Feature>getFeatures(){return features;}

    public String toString(){
        StringBuffer stringBuffer=new StringBuffer();
        for(int row=0;row<data.length;row++){
            for(int column=0;column<data[row].length;column++){
                stringBuffer.append(data[row][column]);
                IntStream.range(0, 24-data[row][column].length()).forEach(i->stringBuffer.append(" "));
            }
            stringBuffer.append("\n");
            if(row==0){
                IntStream.range(0,108).forEach(i->stringBuffer.append("-"));
                stringBuffer.append("\n");
            }
        }
        return stringBuffer.toString();
    }
    public static HashMap<String,Double> getGiniIndex(String[][] data){
        HashMap<String,Double> gini = new HashMap<>();
        int columns = data[0].length;
        for(int i=0;i<columns;i++){
            temp =0;
            Feature current = new Feature(data,i);
            HashSet<FeatureValue> featureValues = current.getFeatureValues();
            for(FeatureValue featureValue:featureValues){
                temp +=  ((double)(featureValue.getOccurences())/(data.length - 1)*(double)(featureValue.getOccurences())/(data.length - 1));
            }
            gini.put(current.getName(),temp);
        }
        return gini;
    }
    double minusPlog2(double p) {
        double returnValue=0;
        if(p!=0) returnValue =(-1)*p*Math.log(p)/Math.log(2);
        return returnValue;
    }


}