import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;
public class Driver {
    static String[][] WEATHER=
            {{"outlook","temperature","humidity","windy","play"},
                    {"sunny", "hot", "high", "FALSE", "no"},
                    {"sunny", "hot", "high", "TRUE", "no"},
                    {"overcast", "hot", "high", "FALSE", "yes"},
                    {"rainy", "mild", "high", "FALSE", "yes"},
                    {"rainy", "cool", "normal", "FALSE", "yes"},
                    {"rainy", "cool", "normal", "TRUE", "no"},
                    {"overcast", "cool", "normal", "TRUE", "yes"},
                    {"sunny", "mild", "high", "FALSE", "no"},
                    {"sunny", "cool", "normal", "FALSE", "yes"},
                    {"rainy", "mild", "normal", "FALSE", "yes"},
                    {"sunny", "mild", "normal", "TRUE", "yes"},
                    {"overcast", "mild", "high", "TRUE", "yes"},
                    {"overcast", "hot", "normal", "FALSE", "yes"},
                    {"rainy", "mild", "high", "TRUE", "no"},
            };
    public static void main(String[]args){
        Driver driver=new Driver();
        HashMap<String,String[][]> datas=new HashMap<String,String[][]>();
        datas.put("WEATHER",WEATHER);
        datas.keySet().forEach(data->{
            HashMap<Feature,Double> featureInfoGain=new HashMap<Feature,Double>();
            DataSet dataSet=new DataSet(datas.get(data));
            double entropy = dataSet.getEntropy();
            IntStream.range(0,datas.get(data)[0].length-1).forEach(column->{
                Feature feature=new Feature(datas.get(data),column);
                ArrayList<DataSet> dataSets=new ArrayList<DataSet>();
                feature.getFeatureValues().stream().forEach(featureValue->dataSets.add(driver.createDataSet(featureValue, column, datas.get(data))));
                double summation=0;
                for(int i=0;i<dataSets.size();i++) {
                    summation += ((double) (dataSets.get(i).getData().length - 1) / (datas.get(data).length - 1)) * dataSets.get(i).getEntropy();
                }
                featureInfoGain.put(feature,dataSet.getEntropy()-summation);
            });
            HashMap<String,Double> gini = DataSet.getGiniIndex(datas.get(data));
            System.out.println("<"+data+" DATASET>:\n"+dataSet);
            System.out.println("Entropy: " + entropy + "\n");
            System.out.println(driver.generateInfogainDisplayTable(featureInfoGain,entropy,gini));

            System.out.println("Best Feature to Split on is " + " '" + driver.determaineSplitOnFeature(featureInfoGain) + "' " + " based on Information Gain" +"\n");
            System.out.println("\n\n");
        });

    }
    DataSet createDataSet(FeatureValue featureValue,int column,String[][]data){
        String[][] returnData=new String[featureValue.getOccurences()+1][data[0].length];
        returnData[0]=data[0];
        int counter=1;
        for(int row=1;row<data.length;row++)
            if(data[row][column]==featureValue.getName())
                returnData[counter++]=data[row];
        return new DataSet(deleteColumn(returnData,column));

    }
    Feature determaineSplitOnFeature(HashMap<Feature,Double>featuresInfoGain){
        Feature splitOnFeature=null;
        Iterator<Feature>iterator=featuresInfoGain.keySet().iterator();
        while(iterator.hasNext()){
            Feature feature =iterator.next();
            if(splitOnFeature==null)splitOnFeature=feature;
            if(featuresInfoGain.get(splitOnFeature)<featuresInfoGain.get(feature))
                splitOnFeature=feature;
        }
        return splitOnFeature;
    }
    StringBuffer generateInfogainDisplayTable(HashMap<Feature,Double>featuresInfoGain,double entropy,HashMap<String,Double> gini){
        StringBuffer stringBuffer=new StringBuffer();
        stringBuffer.append("Feature             Information Gain              Gain Ratio               Gini Index              Impurity\n");
        IntStream.range(0, 110).forEach(i->stringBuffer.append("-"));
        stringBuffer.append("\n");
        Iterator<Feature>iterator=featuresInfoGain.keySet().iterator();
        while(iterator.hasNext()){
            Feature feature=iterator.next();
            stringBuffer.append(feature);
            IntStream.range(0,21-feature.getName().length()).forEach(i->stringBuffer.append(" "));
            stringBuffer.append(String.format("%.8f", featuresInfoGain.get(feature)));
            IntStream.range(0,20).forEach(i->stringBuffer.append(" "));
            stringBuffer.append(String.format("%.8f", featuresInfoGain.get(feature)/entropy));
            IntStream.range(0,15).forEach(i->stringBuffer.append(" "));
            stringBuffer.append(String.format("%.8f", gini.get(feature.getName())));
            IntStream.range(0,13).forEach(i->stringBuffer.append(" "));
            stringBuffer.append(String.format("%.8f", 1-gini.get(feature.getName())) + "\n");
        }
        return stringBuffer;
    }
    String[][] deleteColumn(String[][]data,int deleteColumn){
        String returnData[][] =new String[data.length][data[0].length-1];
        for(int row=0;row<data.length;row++){
            int columnCounter=0;
            for(int column=0;column<data[0].length;column++)
                if(column!=deleteColumn)
                    returnData[row][columnCounter++]=data[row][column];


        }
        return returnData;
    }
}