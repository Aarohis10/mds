import tkinter as tk
import mysql.connector
from tkinter import ttk
import threading

p1 = []
p2 = []
p3 = []
found = 0

def startPartition(result):
    global p1
    global p2
    global p3
    for i in range(0,len(result),3):
        partition1.insert("","end",values=result[i])
        p1.append(result[i])
        partition2.insert("","end",values=result[i+1])
        p2.append(result[i+1])
        partition3.insert("","end",values=result[i+2])
        p3.append(result[i+2])

def searchEachPartition(partition,searchval,pno):
    global searchRes
    global found
    for i in range(len(partition)):
        if partition[i][2] == int(searchval):
            searchRes.config(text="Search Result: found at record number "+str(i+1)+" of partition number "+str(pno))
            print("Search Result: found at record number "+str(i+1)+" of partition number "+str(pno))
            found = 1
            break
    if found == 0:
        searchRes.config(text="Search Result: not found")
        print("Search Result: not found")

def search():
    global p1
    global p2
    global p3
    first = threading.Thread(target=searchEachPartition,args=(p1,searchQ.get(),1))
    second = threading.Thread(target=searchEachPartition,args=(p2,searchQ.get(),2))
    third = threading.Thread(target=searchEachPartition,args=(p3,searchQ.get(),3))
    first.start()
    second.start()
    third.start()

root = tk.Tk()
root.geometry("1500x800")
root.title("ROUND ROBIN PARTITIONING")
maintree = ttk.Treeview(root,show='headings',height=10)
maintree.place(x=20,y=20)
verscrlbar = ttk.Scrollbar(root, orient="vertical", command=maintree.yview)
verscrlbar.pack(side='right', fill='x')

conn = mysql.connector.connect(host='localhost', user='root', password='sayyam123', database='sample')
cursor = conn.cursor()
cursor.execute("SELECT * FROM sample")
field_names = [i[0] for i in cursor.description]
maintree["columns"] = field_names
for i in field_names:
    maintree.heading(i, text=i)
rows = cursor.fetchall()
for row in rows:
    maintree.insert("", "end", values=row)

startbtn = tk.Button(root,text="Partition",command=lambda:startPartition(rows),bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
startbtn.place(x=200,y=400,width=100,height=50)

lab = tk.Label(root,text="Round Robin partitioning",bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
lab.place(x=150,y=600)

partition1label = tk.Label(root,text="Partition 1",bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
partition1label.place(x=700,y=0)
partition1 = ttk.Treeview(root,show='headings',height=7)
partition1.place(x=700,y=20)
partition1["columns"] = field_names
for i in field_names:
    partition1.heading(i, text=i)

partition2label = tk.Label(root,text="Partition 2",bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
partition2label.place(x=700,y=230)
partition2 = ttk.Treeview(root,show='headings',height=7)
partition2.place(x=700,y=250)
partition2["columns"] = field_names
for i in field_names:
    partition2.heading(i, text=i)

partition3label = tk.Label(root,text="Partition 3",bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
partition3label.place(x=700,y=480)
partition3 = ttk.Treeview(root,show='headings',height=7)
partition3.place(x=700,y=500)
partition3["columns"] = field_names
for i in field_names:
    partition3.heading(i, text=i)

searchQ = tk.Entry(root,width=30)
searchQ.place(x=20,y=470)
searchButton = tk.Button(root,text="Search",command=search,bg='#3DB2FF',fg='white',font=('monospace',12,'bold'))
searchButton.place(x=180,y=450,width=100,height=50)

searchRes = tk.Label(root,text="",fg='black',font=('monospace',12,'bold'))
searchRes.place(x=150,y=520)

root.mainloop()