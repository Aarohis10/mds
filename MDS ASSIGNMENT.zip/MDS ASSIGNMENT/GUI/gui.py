import tkinter as tk
import mysql.connector
from tkinter import *
from tkinter import ttk


def Execute():
    for i in tree.get_children():
        tree.delete(i)
    msg.config(text="")
    msglbl.config(text="")
    resultlbl.config(text="")
    res.config(text="")
    if query.get() == "":
        return
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="sayyam123",
        database="players"
    )
    cursor = conn.cursor()
    try:
        cursor.execute(query.get())
        if query.get().lower().startswith("select"):
            num_fields = len(cursor.description)
            field_names = [i[0] for i in cursor.description]
            result = cursor.fetchall()
            if len(result) == 0:
                msg.config(text="No results found")
                return
            tree["columns"] = field_names
            for i in field_names:
                tree.heading(i, text=i)
            for row in result:
                tree.insert("", "end", values=row)
            if len(result) < 10:
                tree.config(height=len(result))
            else:
                tree.config(height=10)
            msglbl.config(text="Response - ")
            msg.config(text="Query executed Successfully!!",
                       foreground="green")
            resultlbl.config(text="Result - ")
        else:
            conn.commit()
            msglbl.config(text="Response - ")
            msg.config(text=str(cursor.rowcount) +
                       " record(s) affected", foreground="green")
            cursor.execute("select * from players;")
            result = cursor.fetchall()
            for row in result:
                tree.insert("", "end", values=row)
            if len(result) < 10:
                tree.config(height=len(result))
            else:
                tree.config(height=10)
    except mysql.connector.Error as err:
        msglbl.config(text="Response - ")
        msg.config(text=err, foreground="red", wraplength=350)

    conn.close()
    query.config(text="")


root = tk.Tk()
root.geometry("1500x800")
root.title("GUI")

querylbl = tk.Label(root, text="Query -", foreground="#3DB2FF")
querylbl.place(x=500, y=30)

query = tk.Entry(root, width=100)
query.place(x=550, y=20, width=300, height=40)

submitbtn = tk.Button(root, text="Execute",
                      bg='#3DB2FF', command=Execute)
submitbtn.place(x=650, y=70, width=55)

msglbl = tk.Label(root, text="", foreground="#3DB2FF")
msglbl.place(x=500, y=100)

msg = tk.Label(root, text="")
msg.place(x=570, y=100)

resultlbl = tk.Label(root, text="", foreground="#3DB2FF")
resultlbl.place(x=500, y=140)

res = tk.Label(root, text="")
res.place(x=550, y=170)

tree = ttk.Treeview(root, show='headings')
tree.place(x=300, y=180)
verscrlbar = ttk.Scrollbar(root, orient="vertical", command=tree.yview)
style = ttk.Style(root)
style.configure('Treeview', rowheight=45)
verscrlbar.pack(side='right', fill='x')

root.mainloop()
