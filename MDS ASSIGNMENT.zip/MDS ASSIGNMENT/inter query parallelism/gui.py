import tkinter as tk
import mysql.connector
from tkinter import ttk
import threading

root = tk.Tk()
root.geometry("1500x800")
root.title("parallel query")

def executeOne(result,query):
    conn = mysql.connector.connect(host='localhost',database='sample',user='root',password='sayyam123')
    cursor = conn.cursor()
    cursor.execute(query)
    feilds = [i[0] for i in cursor.description]
    result['columns'] = feilds
    for i in feilds:
        result.heading(i, text=i)
    rows = cursor.fetchall()
    for row in rows:
        result.insert('', 'end', values=row)
    conn.close()


def execute():
    global res1
    global res2
    global res3
    query1 = threading.Thread(target=executeOne,args=(res1,qry1.get()))
    query2 = threading.Thread(target=executeOne,args=(res2,qry2.get()))
    query3 = threading.Thread(target=executeOne,args=(res3,qry3.get()))
    query1.start()
    query2.start()
    query3.start()

# Queries
qry1 = tk.Entry(root, width=100)
qry2 = tk.Entry(root, width=100)
qry3 = tk.Entry(root, width=100)
tk.Label(root, text="Query 1", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=20)
qry1.place(x=20, y=50)
tk.Label(root, text="Query 2", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=80)
qry2.place(x=20, y=110)
tk.Label(root, text="Query 3", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=140)
qry3.place(x=20, y=170)

# Execute button
tk.Button(root, text="Execute", bg='#3DB2FF', fg='white',command=execute, 
          font=('monospace', 12, 'bold')).place(x=750, y=100)

# Result 1
tk.Label(root, text="Result 1", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=200)
res1 = ttk.Treeview(root, show='headings', height=5)
res1.place(x=20, y=230)

# Result 2
tk.Label(root, text="Result 2", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=360)
res2 = ttk.Treeview(root, show='headings', height=5)
res2.place(x=20, y=390)

# Result 3
tk.Label(root, text="Result 3", bg='#3DB2FF', fg='white',
         font=('monospace', 12, 'bold')).place(x=20, y=520)
res3 = ttk.Treeview(root, show='headings', height=5)
res3.place(x=20, y=550)

root.mainloop()